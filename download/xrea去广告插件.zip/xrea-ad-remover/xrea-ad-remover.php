<?php 
/* 
Plugin Name: XREA AD Remover
Plugin URI: 
Description: XREAの広告を削除（WP-LOGIN.PHPは削除していない）
Version: 0.0.1
Author: masarap
Author URI: 
*/ 

function InsertAdminNoBannerTag() {
	echo '<!--nobanner-->';
}
add_action( 'admin_head', 'InsertAdminNoBannerTag' );

function InsertNoBannerTag() {
	echo '<!--nobanner-->';
}
add_action( 'wp_head', 'InsertNoBannerTag' );
